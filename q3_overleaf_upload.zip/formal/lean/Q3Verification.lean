import Std

namespace Q3Verification

abbrev ModelSet (alpha : Type) := alpha -> Prop

def Refines {alpha : Type} (new old : ModelSet alpha) : Prop :=
  forall x, new x -> old x

def posteriorUpdate {alpha : Type} (prior : ModelSet alpha) (observation : alpha -> Prop) : ModelSet alpha :=
  fun x => And (prior x) (observation x)

theorem posterior_update_refines {alpha : Type} (prior : ModelSet alpha) (observation : alpha -> Prop) :
    Refines (posteriorUpdate prior observation) prior := by
  intro x hx
  exact hx.1

theorem posterior_update_is_sound {alpha : Type} (prior : ModelSet alpha) (observation : alpha -> Prop)
    {x : alpha} (hx : posteriorUpdate prior observation x) : observation x := by
  exact hx.2

theorem sequential_updates_commute {alpha : Type} (prior : ModelSet alpha) (a b : alpha -> Prop) :
    posteriorUpdate (posteriorUpdate prior a) b =
      posteriorUpdate (posteriorUpdate prior b) a := by
  funext x
  apply propext
  constructor
  case mp =>
    intro hx
    exact And.intro (And.intro hx.1.1 hx.2) hx.1.2
  case mpr =>
    intro hx
    exact And.intro (And.intro hx.1.1 hx.2) hx.1.2

def clearFailureUpdate {alpha : Type} (prior : ModelSet alpha) (distance : alpha -> Nat)
    (exclusionRadius : Nat) : ModelSet alpha :=
  posteriorUpdate prior (fun x => exclusionRadius < distance x)

theorem clear_failure_refines {alpha : Type} (prior : ModelSet alpha) (distance : alpha -> Nat)
    (exclusionRadius : Nat) :
    Refines (clearFailureUpdate prior distance exclusionRadius) prior := by
  exact posterior_update_refines prior _

theorem clear_failure_excludes_nearby {alpha : Type} (prior : ModelSet alpha) (distance : alpha -> Nat)
    (exclusionRadius : Nat) {x : alpha}
    (hx : clearFailureUpdate prior distance exclusionRadius x) :
    exclusionRadius < distance x := by
  exact hx.2

def coverageNumerator (distanceM : Nat) : Nat :=
  if distanceM <= 1000 then 500
  else if distanceM < 1500 then 1500 - distanceM
  else 0

theorem coverage_probability_bounded (distanceM : Nat) :
    coverageNumerator distanceM <= 500 := by
  unfold coverageNumerator
  split
  case isTrue => omega
  case isFalse =>
    split <;> omega

theorem coverage_probability_monotone {d1 d2 : Nat} (h : d1 <= d2) :
    coverageNumerator d2 <= coverageNumerator d1 := by
  by_cases h2a : d2 <= 1000
  case pos =>
    have h1a : d1 <= 1000 := Nat.le_trans h h2a
    simp [coverageNumerator, h2a, h1a]
  case neg =>
    by_cases h2b : d2 < 1500
    case pos =>
      have h1b : d1 < 1500 := Nat.lt_of_le_of_lt h h2b
      by_cases h1a : d1 <= 1000
      case pos =>
        simp [coverageNumerator, h2a, h2b, h1a]
        omega
      case neg =>
        simp [coverageNumerator, h2a, h2b, h1a, h1b]
        omega
    case neg =>
      simp [coverageNumerator, h2a, h2b]

theorem certain_coverage_region {distanceM : Nat} (h : distanceM <= 1000) :
    coverageNumerator distanceM = 500 := by
  simp [coverageNumerator, h]

theorem impossible_coverage_region {distanceM : Nat} (h : 1500 <= distanceM) :
    coverageNumerator distanceM = 0 := by
  have hNotLe : Not (distanceM <= 1000) := by omega
  have hNotLt : Not (distanceM < 1500) := by omega
  simp [coverageNumerator, hNotLe, hNotLt]

structure DistanceModel (alpha : Type) where
  dist : alpha -> alpha -> Nat
  triangle : forall x y z, dist x z <= dist x y + dist y z

def serviceEdge {alpha : Type} (D : DistanceModel alpha) (start waypoint target : alpha) : Nat :=
  D.dist start waypoint + D.dist waypoint target

theorem direct_edge_no_longer_than_service_edge {alpha : Type} (D : DistanceModel alpha)
    (start waypoint target : alpha) :
    D.dist start target <= serviceEdge D start waypoint target := by
  exact D.triangle start waypoint target

def ShouldReplan (lockedLength candidateLength thresholdM : Nat) : Prop :=
  candidateLength + thresholdM < lockedLength

theorem accepted_replan_is_strictly_shorter {lockedLength candidateLength thresholdM : Nat}
    (h : ShouldReplan lockedLength candidateLength thresholdM) :
    candidateLength < lockedLength := by
  unfold ShouldReplan at h
  omega

theorem rejected_small_improvement_is_locked {lockedLength candidateLength thresholdM : Nat}
    (h : lockedLength <= candidateLength + thresholdM) :
    Not (ShouldReplan lockedLength candidateLength thresholdM) := by
  unfold ShouldReplan
  omega

theorem regret_threshold_time_conversion : 75 = 5 * 15 := by
  decide

def stopThresholdBp (knownSources : Nat) : Nat :=
  match knownSources with
  | 10 => 5800
  | 11 => 6800
  | 12 => 7500
  | 13 => 9000
  | 14 => 8500
  | 15 => 8500
  | _ => 10000

theorem stop_threshold_table :
    And (stopThresholdBp 10 = 5800)
      (And (stopThresholdBp 11 = 6800)
        (And (stopThresholdBp 12 = 7500)
          (And (stopThresholdBp 13 = 9000)
            (And (stopThresholdBp 14 = 8500)
              (stopThresholdBp 15 = 8500))))) := by
  decide

theorem formal_stop_thresholds_are_probabilities {k : Nat} (h1 : 10 <= k) (h2 : k <= 15) :
    stopThresholdBp k <= 10000 := by
  have hk : Or (k = 10) (Or (k = 11) (Or (k = 12) (Or (k = 13) (Or (k = 14) (k = 15))))) := by
    omega
  rcases hk with h | h | h | h | h | h <;> subst k <;> decide

theorem source_upper_bound_forces_equality {known trueCount : Nat}
    (hKnown : known = 16) (hLower : known <= trueCount) (hUpper : trueCount <= 16) :
    trueCount = 16 := by
  omega

structure FormalRun where
  virtualTimeUs : Nat
  clearedSources : Nat
deriving DecidableEq, Repr

def formalRuns : List FormalRun :=
  [ { virtualTimeUs := 2964025966, clearedSources := 12 }
  , { virtualTimeUs := 2850243268, clearedSources := 16 }
  , { virtualTimeUs := 2882007579, clearedSources := 10 }
  ]

def totalVirtualTimeUs : Nat :=
  formalRuns.foldl (fun total run => total + run.virtualTimeUs) 0

def totalClearedSources : Nat :=
  formalRuns.foldl (fun total run => total + run.clearedSources) 0

def roundedDiv (numerator denominator : Nat) : Nat :=
  (numerator + denominator / 2) / denominator

theorem formal_run_total_time_exact : totalVirtualTimeUs = 8696276813 := by
  decide

theorem formal_run_source_count_exact : totalClearedSources = 38 := by
  decide

theorem weighted_average_rounds_to_reported_value :
    roundedDiv totalVirtualTimeUs totalClearedSources = 228849390 := by
  decide

theorem individual_averages_round_to_reported_values :
    And (roundedDiv 2964025966 12 = 247002164)
      (And (roundedDiv 2850243268 16 = 178140204)
        (roundedDiv 2882007579 10 = 288200758)) := by
  decide

def roundedRate (success total scale : Nat) : Nat :=
  roundedDiv (success * scale) total

theorem holdout_full_clear_rate_rounds_to_91_43_percent :
    roundedRate 64 70 10000 = 9143 := by
  decide

theorem holdout_source_clear_rate_rounds_to_99_327_percent :
    roundedRate 885 891 100000 = 99327 := by
  decide

theorem fixed_sample_full_clear_rate_is_100_percent :
    roundedRate 35 35 10000 = 10000 := by
  decide

end Q3Verification
