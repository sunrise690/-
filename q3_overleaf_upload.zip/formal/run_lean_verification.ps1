param()

# Lean verification runner.
$ErrorActionPreference = 'Stop'
& python (Join-Path $PSScriptRoot 'check_source_alignment.py')
if ($LASTEXITCODE -ne 0) { throw 'Source alignment failed.' }
Push-Location (Join-Path $PSScriptRoot 'lean')
try { & (Join-Path $env:USERPROFILE '.elan\bin\lean.exe') 'Q3Verification.lean' } finally { Pop-Location }
if ($LASTEXITCODE -ne 0) { throw 'Lean verification failed.' }
