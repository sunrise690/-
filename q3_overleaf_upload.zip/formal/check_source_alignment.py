from decimal import Decimal
from fractions import Fraction
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise AssertionError(message)


tuning = json.loads((ROOT / 'program/official/code/q3_tuning.json').read_text(encoding='utf-8'))
expected_tuning = {
    'particle_n': 32000,
    'particle_rebuild_n': 64000,
    'service_waypoint_min_prob': Decimal('0.4'),
    'service_uncertainty_trigger': 80,
    'route_batch_adaptive_regret_m': 75,
    'stop_thr_10': Decimal('0.58'),
    'stop_thr_11': Decimal('0.68'),
    'stop_thr_12': Decimal('0.75'),
    'stop_thr_13': Decimal('0.9'),
}

for key, expected in expected_tuning.items():
    actual = tuning[key]
    if isinstance(expected, Decimal):
        actual = Decimal(str(actual))
    require(actual == expected, f'tuning mismatch for {key}: {actual} != {expected}')

require(Decimal(str(tuning.get('stop_thr_14', 0.85))) == Decimal('0.85'), 'stop_thr_14 mismatch')
require(Decimal(str(tuning.get('stop_thr_15', 0.85))) == Decimal('0.85'), 'stop_thr_15 mismatch')

formal_text = (ROOT / 'reports/formal_summary.json').read_text(encoding='utf-8')


def first_decimal(field):
    match = re.search(rf'{re.escape(field)}[^0-9]+([0-9]+(?:\.[0-9]+)?)', formal_text)
    require(match is not None, f'missing field in formal summary: {field}')
    return Decimal(match.group(1))


require(first_decimal('cleared_sources') == Decimal('38.0'), 'formal source total mismatch')
require(first_decimal('total_virtual_time_s') == Decimal('8696.276813'), 'formal time total mismatch')
require(first_decimal('weighted_average_s_per_source') == Decimal('228.84939'), 'weighted mean mismatch')

validation = json.loads((ROOT / 'reports/validation_summary.json').read_text(encoding='utf-8'))
require(validation['fixed']['runs'] == 35, 'fixed run count mismatch')
require(validation['fixed']['fullclear_runs'] == 35, 'fixed full-clear count mismatch')
require(validation['holdout']['runs'] == 70, 'holdout run count mismatch')
require(validation['holdout']['fullclear_runs'] == 64, 'holdout full-clear count mismatch')

source_rate = Fraction(str(validation['holdout']['source_clear_rate'])).limit_denominator(10000)
require(source_rate == Fraction(885, 891), f'holdout source rate mismatch: {source_rate}')

print('Source alignment passed.')
