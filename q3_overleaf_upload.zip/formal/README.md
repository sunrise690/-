# Question 3 Lean verification

`lean/Q3Verification.lean` checks the structural properties and exact arithmetic
claims used in Question 3:

- posterior filtering only removes candidates;
- a failed clear excludes candidates inside the stated radius;
- coverage probability is bounded and monotone in survey distance;
- a service waypoint cannot shorten the corresponding direct metric edge;
- route replanning requires an improvement beyond the regret threshold;
- stopping thresholds are legal probabilities and the 16-source bound is sound;
- formal-run totals, rounded averages, and validation percentages match the paper.

Run from the workspace root:

```powershell
powershell -ExecutionPolicy Bypass -File .\formal\run_lean_verification.ps1
```

The proof does not claim that a finite particle sample exactly represents the
continuous posterior, that the holdout set covers every spatial configuration,
that the posterior stopping rule guarantees complete clearance, or that the
large-instance heuristic is globally optimal. Those remain empirical claims.
